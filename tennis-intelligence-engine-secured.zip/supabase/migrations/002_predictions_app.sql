-- Table d'analyses / prédictions alignée sur le store applicatif
-- Table applicative autonome : analyses, sélections et règlements TIE.

CREATE TABLE IF NOT EXISTS app_predictions (
  id                TEXT PRIMARY KEY,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  player1           TEXT NOT NULL,
  player2           TEXT NOT NULL,
  event_id          TEXT,
  tournament        TEXT,
  is_live           BOOLEAN DEFAULT false,
  start_time        TIMESTAMPTZ,
  status            TEXT NOT NULL CHECK (status IN (
                      'SELECTED', 'NO_VALID_PREDICTION', 'AMBIGUOUS', 'ERROR'
                    )),
  market            TEXT,
  selection         TEXT,
  selection_key     TEXT,
  odds              NUMERIC(8,3),
  estimated_prob    NUMERIC(6,4),
  expected_value    NUMERIC(8,4),
  confidence        NUMERIC(5,2),
  risk_score        NUMERIC(5,2),
  data_quality      NUMERIC(4,3),
  model             TEXT,
  settled           BOOLEAN DEFAULT false,
  settled_at        TIMESTAMPTZ,
  result            TEXT CHECK (result IS NULL OR result IN ('win', 'loss', 'void', 'pending')),
  profit_units      NUMERIC(8,4),
  notes             TEXT,
  raw               JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_app_predictions_created ON app_predictions (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_app_predictions_status ON app_predictions (status);
CREATE INDEX IF NOT EXISTS idx_app_predictions_settled ON app_predictions (settled) WHERE settled = true;

ALTER TABLE public.app_predictions ENABLE ROW LEVEL SECURITY;

-- TIE currently accesses this table only from its Next.js server using the
-- server-only SUPABASE_SERVICE_ROLE_KEY. No browser/anon/authenticated access.
REVOKE ALL ON TABLE public.app_predictions FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.app_predictions TO service_role;

COMMENT ON TABLE app_predictions IS 'Analyses TIE — source de vérité dashboard / ROI';
