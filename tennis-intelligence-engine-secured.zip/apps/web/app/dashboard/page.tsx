"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";

type Stats = {
  backend?: string;
  totalAnalyses: number;
  selected: number;
  noValid: number;
  settled: number;
  wins: number;
  losses: number;
  voids: number;
  hitRate: number | null;
  roi: number | null;
  profitUnits: number;
  avgOdds: number | null;
  avgEv: number | null;
  byMarket: Record<string, { n: number; wins: number; losses: number; profit: number }>;
  byModel: Record<string, { n: number; wins: number; losses: number; profit: number }>;
  recent: Array<{
    id: string;
    createdAt: string;
    player1: string;
    player2: string;
    status: string;
    market?: string;
    selection?: string;
    odds?: number;
    expectedValue?: number;
    settled?: boolean;
    result?: string;
    profitUnits?: number;
    model?: string;
  }>;
};

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [settling, setSettling] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/performance");
      setStats(await res.json());
    } catch {
      setStats(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function settle(id: string, result: "win" | "loss" | "void") {
    setSettling(id);
    try {
      await fetch("/api/predictions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "settle", id, result }),
      });
      await load();
    } finally {
      setSettling(null);
    }
  }

  return (
    <main className="mx-auto max-w-4xl px-4 py-12">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <div className="text-xs font-medium uppercase tracking-wider text-emerald-400">
            Tennis Intelligence Engine
          </div>
          <h1 className="mt-1 text-2xl font-bold text-white">Dashboard performances</h1>
          <p className="mt-1 text-sm text-zinc-500">
            Uniquement des données réellement enregistrées — zéro fictif
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={load}
            className="rounded-lg border border-zinc-700 px-3 py-2 text-sm text-zinc-300 hover:border-zinc-500"
          >
            Rafraîchir
          </button>
          <Link
            href="/"
            className="rounded-lg bg-emerald-600 px-3 py-2 text-sm font-medium text-white hover:bg-emerald-500"
          >
            Analyser
          </Link>
        </div>
      </div>

      {loading && (
        <div className="text-center text-zinc-500 py-20">Chargement…</div>
      )}

      {!loading && stats && (
        <>
          {stats.backend && (
            <div className="mb-4 text-xs text-zinc-500">
              Backend stockage : <span className="text-zinc-300">{stats.backend}</span>
            </div>
          )}
          {/* KPIs */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Kpi label="Analyses" value={String(stats.totalAnalyses)} />
            <Kpi label="Sélections" value={String(stats.selected)} />
            <Kpi label="Sans valeur" value={String(stats.noValid)} />
            <Kpi label="Settled" value={String(stats.settled)} />
            <Kpi
              label="Hit rate"
              value={
                stats.hitRate != null
                  ? `${(stats.hitRate * 100).toFixed(1)}%`
                  : "—"
              }
              sub={`${stats.wins}W / ${stats.losses}L`}
            />
            <Kpi
              label="ROI"
              value={
                stats.roi != null ? `${(stats.roi * 100).toFixed(1)}%` : "—"
              }
              highlight={stats.roi != null && stats.roi > 0}
            />
            <Kpi
              label="Profit (u)"
              value={stats.profitUnits.toFixed(2)}
              highlight={stats.profitUnits > 0}
            />
            <Kpi
              label="Cote moy."
              value={stats.avgOdds != null ? stats.avgOdds.toFixed(2) : "—"}
            />
          </div>

          {stats.totalAnalyses === 0 && (
            <div className="mt-10 rounded-2xl border border-zinc-800 bg-zinc-900/50 p-8 text-center text-zinc-400">
              Aucune analyse enregistrée pour le moment.
              <div className="mt-3">
                <Link href="/" className="text-emerald-400 hover:underline">
                  Lancer une première analyse →
                </Link>
              </div>
            </div>
          )}

          {/* By market */}
          {Object.keys(stats.byMarket).length > 0 && (
            <section className="mt-10">
              <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-zinc-400">
                Par marché
              </h2>
              <div className="overflow-x-auto rounded-xl border border-zinc-800">
                <table className="w-full text-left text-sm">
                  <thead className="bg-zinc-900 text-zinc-500">
                    <tr>
                      <th className="px-4 py-2">Marché</th>
                      <th className="px-4 py-2">N</th>
                      <th className="px-4 py-2">W</th>
                      <th className="px-4 py-2">L</th>
                      <th className="px-4 py-2">Profit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(stats.byMarket).map(([k, v]) => (
                      <tr key={k} className="border-t border-zinc-800">
                        <td className="px-4 py-2 text-zinc-200">{k}</td>
                        <td className="px-4 py-2">{v.n}</td>
                        <td className="px-4 py-2 text-emerald-400">{v.wins}</td>
                        <td className="px-4 py-2 text-red-400">{v.losses}</td>
                        <td className="px-4 py-2">{v.profit.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}

          {/* By model */}
          {Object.keys(stats.byModel).length > 0 && (
            <section className="mt-8">
              <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-zinc-400">
                Par modèle
              </h2>
              <div className="overflow-x-auto rounded-xl border border-zinc-800">
                <table className="w-full text-left text-sm">
                  <thead className="bg-zinc-900 text-zinc-500">
                    <tr>
                      <th className="px-4 py-2">Modèle</th>
                      <th className="px-4 py-2">N</th>
                      <th className="px-4 py-2">W</th>
                      <th className="px-4 py-2">L</th>
                      <th className="px-4 py-2">Profit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(stats.byModel).map(([k, v]) => (
                      <tr key={k} className="border-t border-zinc-800">
                        <td className="px-4 py-2 text-zinc-200">{k}</td>
                        <td className="px-4 py-2">{v.n}</td>
                        <td className="px-4 py-2 text-emerald-400">{v.wins}</td>
                        <td className="px-4 py-2 text-red-400">{v.losses}</td>
                        <td className="px-4 py-2">{v.profit.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}

          {/* History */}
          {stats.recent.length > 0 && (
            <section className="mt-10">
              <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-zinc-400">
                Historique récent
              </h2>
              <ul className="space-y-2">
                {stats.recent.map((p) => (
                  <li
                    key={p.id}
                    className="rounded-xl border border-zinc-800 bg-zinc-900/40 px-4 py-3"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="font-medium text-white">
                          {p.player1} vs {p.player2}
                        </div>
                        <div className="mt-0.5 text-xs text-zinc-500">
                          {new Date(p.createdAt).toLocaleString("fr-FR")}
                          {p.market ? ` · ${p.market}` : ""}
                          {p.model ? ` · ${p.model}` : ""}
                        </div>
                        {p.status === "SELECTED" && (
                          <div className="mt-1 text-sm text-emerald-400">
                            {p.selection} @ {p.odds?.toFixed(2)}
                            {p.expectedValue != null &&
                              ` · EV ${(p.expectedValue * 100).toFixed(1)}%`}
                          </div>
                        )}
                        {p.status === "NO_VALID_PREDICTION" && (
                          <div className="mt-1 text-sm text-amber-500">
                            Aucune prédiction validée
                          </div>
                        )}
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        {p.settled ? (
                          <span
                            className={`text-xs font-semibold uppercase ${
                              p.result === "win"
                                ? "text-emerald-400"
                                : p.result === "loss"
                                  ? "text-red-400"
                                  : "text-zinc-400"
                            }`}
                          >
                            {p.result}
                            {p.profitUnits != null &&
                              ` (${p.profitUnits > 0 ? "+" : ""}${p.profitUnits.toFixed(2)}u)`}
                          </span>
                        ) : p.status === "SELECTED" ? (
                          <div className="flex gap-1">
                            <button
                              disabled={settling === p.id}
                              onClick={() => settle(p.id, "win")}
                              className="rounded bg-emerald-600/20 px-2 py-1 text-xs text-emerald-400 hover:bg-emerald-600/40"
                            >
                              Win
                            </button>
                            <button
                              disabled={settling === p.id}
                              onClick={() => settle(p.id, "loss")}
                              className="rounded bg-red-600/20 px-2 py-1 text-xs text-red-400 hover:bg-red-600/40"
                            >
                              Loss
                            </button>
                            <button
                              disabled={settling === p.id}
                              onClick={() => settle(p.id, "void")}
                              className="rounded bg-zinc-600/20 px-2 py-1 text-xs text-zinc-400 hover:bg-zinc-600/40"
                            >
                              Void
                            </button>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </>
      )}
    </main>
  );
}

function Kpi({
  label,
  value,
  sub,
  highlight,
}: {
  label: string;
  value: string;
  sub?: string;
  highlight?: boolean;
}) {
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/50 p-4">
      <div className="text-xs text-zinc-500">{label}</div>
      <div
        className={`mt-1 text-2xl font-bold ${highlight ? "text-emerald-400" : "text-white"}`}
      >
        {value}
      </div>
      {sub && <div className="mt-0.5 text-xs text-zinc-500">{sub}</div>}
    </div>
  );
}
