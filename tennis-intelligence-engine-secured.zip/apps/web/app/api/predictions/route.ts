import { NextRequest, NextResponse } from "next/server";
import { loadPredictions, settlePrediction } from "@/lib/store";

export async function GET() {
  const list = await loadPredictions();
  return NextResponse.json({ predictions: list, count: list.length });
}

export async function POST(req: NextRequest) {
  try {
    const body: unknown = await req.json();
    if (!body || typeof body !== "object") {
      return NextResponse.json({ error: "Corps de requête invalide." }, { status: 400 });
    }

    const payload = body as Record<string, unknown>;
    if (payload.action !== "settle") {
      return NextResponse.json({ error: "Action non autorisée." }, { status: 400 });
    }
    if (typeof payload.id !== "string" || payload.id.length < 1 || payload.id.length > 160) {
      return NextResponse.json({ error: "Identifiant de prédiction invalide." }, { status: 400 });
    }
    if (!["win", "loss", "void"].includes(String(payload.result))) {
      return NextResponse.json({ error: "Résultat invalide." }, { status: 400 });
    }
    if (payload.notes !== undefined && (typeof payload.notes !== "string" || payload.notes.length > 500)) {
      return NextResponse.json({ error: "Notes invalides (500 caractères maximum)." }, { status: 400 });
    }

    const updated = await settlePrediction(
      payload.id,
      payload.result as "win" | "loss" | "void",
      payload.notes as string | undefined
    );
    if (!updated) {
      return NextResponse.json({ error: "Prediction not found" }, { status: 404 });
    }
    return NextResponse.json({ prediction: updated });
  } catch {
    return NextResponse.json({ error: "Requête impossible à traiter." }, { status: 400 });
  }
}
