import { NextResponse } from "next/server";
import { isSupabaseConfigured } from "@/lib/store";

export async function GET() {
  return NextResponse.json({
    status: "ok",
    service: "tennis-intelligence-engine",
    storage: isSupabaseConfigured() ? "supabase" : "file",
    supabaseConfigured: isSupabaseConfigured(),
    timestamp: new Date().toISOString(),
  });
}
