import { redirect } from "next/navigation";

// L'interface principale est désormais servie en HTML statique.
// Les API Next.js, le backend, le moteur ML et Supabase restent actifs côté serveur.
export default function HomePage() {
  redirect("/tie.html");
}
